"""
Blloku C (Teorema 3 per rrjetin): certifikate nga defekti Volterra i rrjetit, pa derivat Caputo.

Per cdo mod n:  a_n = c_n - mu_n I^alpha a_n,  mu_n = D lam_n.
Defekti i rrjetit:  theta_n(t) = a~_n(t) - c_n + mu_n I^alpha a~_n(t)   (vetem integral, i llogaritshem)
w_n = a~_n - a_n(theta_hat) zgjidh  w + mu I^alpha w = theta  =>
    |w_n(t)| <= |theta_n(t)| + (1 - E_alpha(-mu_n t^alpha)) * sup_{s<=t}|theta_n(s)|  <= 2 sup|theta_n|
    |u~(x,t) - u(x,t;theta_hat)| <= sqrt2 * sum_n |w_n(t)|
Pastaj certifikata Gauss-Newton e certificate_C, por me F(theta_hat) zevendesuar nga rrjeti + kufiri eta.

Rrjeti jepet si funksion a_func(t) -> (len(t), K) me koeficientet modale a~_n(t) (numpy).
Per SpecPINN: a_func = lambda t: model.coeffs(torch.as_tensor(t)).detach().numpy()
Kufizime: sup merret mbi rrjet te fundem kohor (jo kufi rigoroz mbi cdo t); L numerik.
"""
import math
import numpy as np
from scipy.stats import chi2
from frac_identification_baseline import forward, jacobian, ml_neg
from certificate_C import hessian_norm
from experiment_B import C

def _vquad(panels=30, order=8):
    """Kuadrature perberese Gauss-Legendre ne [0,1], e rafinuar drejt v=1 (singulariteti i t^alpha)."""
    xg, wg = np.polynomial.legendre.leggauss(order)
    edges = [0.0] + [1 - 2.0 ** (-k) for k in range(1, panels)] + [1.0]
    V, W = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        V.append(0.5 * (b - a) * xg + 0.5 * (b + a)); W.append(0.5 * (b - a) * wg)
    return np.concatenate(V), np.concatenate(W)
_V, _W = _vquad()

def frac_integral(a_func, t, alpha):
    """I^alpha a (t) = t^alpha/Gamma(1+alpha) * int_0^1 a(t(1 - v^(1/alpha))) dv  (ndryshim variabli)."""
    t = np.asarray(t, float)
    tau = t[:, None] * (1.0 - _V[None, :] ** (1.0 / alpha))       # (T, Q)
    A = a_func(tau.ravel()).reshape(len(t), len(_V), -1)           # (T, Q, K)
    return (t ** alpha / math.gamma(1 + alpha))[:, None] * np.einsum("tqk,q->tk", A, _W)

def vartheta(a_func, cvec, alpha, D, tgrid):
    K = len(cvec); lam = (np.arange(1, K + 1) * np.pi) ** 2
    mu = D * lam
    return a_func(tgrid) - cvec[None, :] + mu[None, :] * frac_integral(a_func, tgrid, alpha), mu

def network_defect_bound(a_func, cvec, theta_hat, x, t, T=1.0, ngrid=200):
    """Kufiri eta_i >= |u~(x_i,t_i) - u(x_i,t_i;theta_hat)| dhe vektori i defekteve."""
    alpha, D = theta_hat
    cvec = np.asarray(cvec, float); K = len(cvec)
    # rrjet kohor: i dendur afer 0 + uniform, perfshin kohet e matjeve
    tg = np.unique(np.concatenate([np.geomspace(1e-4, T, ngrid), np.linspace(T / ngrid, T, ngrid), t]))
    th, mu = vartheta(a_func, cvec, alpha, D, tg)
    g0 = np.abs(a_func(np.array([0.0])) - cvec[None, :])[0]       # defekti ne t=0
    run = np.maximum.accumulate(np.maximum(np.abs(th), g0[None, :]), axis=0)  # sup_{s<=t}
    idx = np.searchsorted(tg, t)
    delta = np.zeros((len(t), K))
    for i, ti in enumerate(t):
        for n in range(K):
            delta[i, n] = abs(th[idx[i], n]) + (1 - ml_neg(alpha, mu[n] * ti ** alpha)) * run[idx[i], n]
    n_idx = np.arange(1, K + 1)
    bound_i = math.sqrt(2) * delta.sum(axis=1)
    t_at_max = tg[np.abs(th).argmax(axis=0)]
    return bound_i, np.abs(th).max(axis=0), g0, t_at_max

def u_net(a_func, x, t):
    A = a_func(t); K = A.shape[1]
    phi = math.sqrt(2) * np.sin(np.pi * x[:, None] * np.arange(1, K + 1)[None, :])
    return (A * phi).sum(axis=1)

def network_certificate(a_func, cvec, theta_hat, x, t, y, sigma, delta=0.05):
    m = len(y)
    bound_i, th_max, g0, t_at_max = network_defect_bound(a_func, cvec, theta_hat, x, t)
    eta = np.linalg.norm(bound_i)
    r_net = y - u_net(a_func, x, t)
    J = jacobian(theta_hat, x, t, C)
    smin = np.linalg.svd(J, compute_uv=False)[-1]
    g = np.linalg.norm(np.linalg.pinv(J) @ r_net)
    q_stat = sigma * np.sqrt(chi2.ppf(1 - delta, 2)) / smin
    L = hessian_norm(theta_hat, x, t)
    kappa = L / (2 * smin)
    a = g + eta / smin + q_stat
    disc = 1 - 4 * kappa * a
    bound = np.inf if disc <= 0 else (1 - np.sqrt(disc)) / (2 * kappa)
    return dict(bound=bound, eta=eta, smin=smin, L=L, gn_net=g, q_stat=q_stat, defect_max=th_max, t_at_defect_max=t_at_max)


def certify_specpinn(model, x, t, y, sigma):
    """Certifikate per nje SpecPINN te trajnuar (K=3 mode si ne eksperimente). Kerkon torch."""
    import torch
    a_func = lambda tt: model.coeffs(torch.as_tensor(np.asarray(tt, float), dtype=torch.float64)).detach().numpy()
    th_hat = np.array([model.alpha.item(), model.D.item()])
    cvec = model.c.detach().numpy()
    return network_certificate(a_func, cvec, th_hat, np.asarray(x, float), np.asarray(t, float),
                               np.asarray(y, float), sigma)
