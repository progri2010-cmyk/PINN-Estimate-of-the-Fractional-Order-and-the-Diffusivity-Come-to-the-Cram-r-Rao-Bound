"""
PINN spektral-hibrid per  d_t^alpha u = D u_xx  (Dirichlet 0, u0 = sum c_n phi_n).

Ansatz:   u(x,t) = sum_{n=1..K} a_n(s) phi_n(x),   s = t^alpha,   phi_n = sqrt2 sin(n pi x)
          a_n(s) = c_n + s * h_n(s)        (h = MLP me nje hyrje s) -> IC e forcuar
Fizika:   d_t^alpha a_n + D lam_n a_n = 0,  lam_n = (n pi)^2   (nuk ka x fare)
Mbetja:   L1 mbi a_n ne rrjet uniform kohor, vetem per t >= skip_frac*T, e normalizuar me (1+D lam_n).

Verifikuar me NumPy (jo me PyTorch): mbetja e koeficienteve te sakte ka RMS ~1e-4 (M=100),
~7e-5 (M=400) -> kjo eshte dyshemeja e skemes.
STATUSI: kodi PyTorch nuk eshte ekzekutuar ne mjedisin ku u shkrua.

Kujdes metodologjik: kjo nuk eshte PINN i plote (baza sinusoidale ne x eshte e dhene,
vetem varesia kohore mesohet). Ne krahasimin me fPINN duhet thene hapur.
"""
import math
import numpy as np
import torch
import torch.nn as nn

from pinn_alpha_D import l1_caputo  # ripërdor skemen L1 te verifikuar

torch.set_default_dtype(torch.float64)


class SpecPINN(nn.Module):
    def __init__(self, c, K=None, width=64, depth=3, alpha_init=0.5, D_init=1.0,
                 a_lo=0.05, a_hi=0.98):
        super().__init__()
        K = K or len(c)
        c_full = torch.zeros(K)
        c_full[:len(c)] = torch.as_tensor(c, dtype=torch.float64)
        self.register_buffer("c", c_full)
        self.register_buffer("lam", (torch.arange(1, K + 1, dtype=torch.float64) * math.pi) ** 2)
        self.K, self.a_lo, self.a_hi = K, a_lo, a_hi
        layers, d_in = [], 1
        for _ in range(depth):
            layers += [nn.Linear(d_in, width), nn.Tanh()]
            d_in = width
        layers += [nn.Linear(d_in, K)]
        self.net = nn.Sequential(*layers)
        p = (alpha_init - a_lo) / (a_hi - a_lo)
        self.a_raw = nn.Parameter(torch.tensor(math.log(p / (1 - p))))
        self.logD = nn.Parameter(torch.tensor(math.log(D_init)))

    @property
    def alpha(self):
        return self.a_lo + (self.a_hi - self.a_lo) * torch.sigmoid(self.a_raw)

    @property
    def D(self):
        return torch.exp(self.logD)

    def coeffs(self, t):
        """t: (T,) -> a: (T, K)."""
        s = (t ** self.alpha)[:, None]
        return self.c[None, :] + s * self.net(s)

    def u(self, x, t):
        """x, t: (m,) -> u: (m,)."""
        n = torch.arange(1, self.K + 1, dtype=x.dtype)
        phi = math.sqrt(2.0) * torch.sin(math.pi * x[:, None] * n[None, :])
        return (self.coeffs(t) * phi).sum(dim=1)


def residual(model, T=1.0, M=200, skip_frac=0.1):
    tau = T / M
    t = torch.linspace(0.0, T, M + 1)
    A = model.coeffs(t).T                                # (K, M+1)
    cap = l1_caputo(A, tau, model.alpha)                 # (K, M) ne t_1..t_M
    res = cap + model.D * model.lam[:, None] * A[:, 1:]
    scale = (1.0 + model.D * model.lam).detach()[:, None]
    n0 = max(1, int(skip_frac * M))
    return (res / scale)[:, n0 - 1:]


def volterra_defect(model, tg, Vn, Wn):
    """Defekti Volterra theta_n(t)=a~_n(t)-c_n+mu_n I^alpha a~_n(t) ne kohet tg; forma (T, K).
    I^alpha a(t) = t^alpha/Gamma(1+alpha) * sum_q w_q a(t(1-v_q^(1/alpha)))  (e njejta formule si ne network_certificate)."""
    alpha, D = model.alpha, model.D
    T_, Q_ = tg.shape[0], Vn.shape[0]
    tau = tg[:, None] * (1.0 - Vn[None, :] ** (1.0 / alpha))              # (T, Q)
    A = model.coeffs(tau.reshape(-1)).reshape(T_, Q_, model.K)             # (T, Q, K)
    pref = (tg ** alpha / torch.exp(torch.lgamma(1.0 + alpha)))[:, None]
    I = pref * (A * Wn[None, :, None]).sum(dim=1)                          # (T, K)
    mu = D * model.lam
    return model.coeffs(tg) - model.c[None, :] + mu[None, :] * I


def train(c, x_d, t_d, y_d, T=1.0, M=200, sigma=1e-2, epochs=5000, lbfgs_iters=300,
          lr=2e-3, w_pde=100.0, w_pde_final=1e5, w_data=1.0, skip_frac=0.1, res_type="l1", alpha_init=0.5, D_init=1.0, seed=0,
          theta_fixed=None, verbose=True, width=64, depth=3):
    torch.manual_seed(seed)
    if theta_fixed is not None:
        alpha_init, D_init = theta_fixed
    model = SpecPINN(c, width=width, depth=depth, alpha_init=alpha_init, D_init=D_init)
    if theta_fixed is not None:
        model.a_raw.requires_grad_(False)
        model.logD.requires_grad_(False)
    params = [q for q in model.parameters() if q.requires_grad]
    x_d, t_d, y_d = [torch.as_tensor(a, dtype=torch.float64) for a in (x_d, t_d, y_d)]

    state = {"w": w_pde}

    if res_type == "volterra":
        from network_certificate import _vquad
        Vn, Wn = [torch.as_tensor(a, dtype=torch.float64) for a in _vquad()]
        tg = torch.as_tensor(np.unique(np.concatenate([np.geomspace(1e-3, T, 60), np.linspace(T / 60, T, 60)])),
                             dtype=torch.float64)

    def loss_fn():
        if res_type == "volterra":
            l_pde = (volterra_defect(model, tg, Vn, Wn) ** 2).mean()
        else:
            l_pde = (residual(model, T, M, skip_frac) ** 2).mean()
        l_dat = ((model.u(x_d, t_d) - y_d) ** 2).mean() / sigma ** 2
        return state["w"] * l_pde + w_data * l_dat, l_pde, l_dat

    opt = torch.optim.Adam(params, lr=lr)
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.5 ** (1.0 / max(1, epochs // 4)))
    for ep in range(epochs):
        state["w"] = w_pde * (w_pde_final / w_pde) ** (ep / max(1, epochs - 1))  # vazhdim penaliteti
        opt.zero_grad()
        L, lp, ld = loss_fn()
        L.backward()
        opt.step()
        sched.step()
        if verbose and ep % 1000 == 0:
            print(f"  ep {ep:5d} L={L.item():.3e} pde={lp.item():.3e} dat={ld.item():.3e} "
                  f"alpha={model.alpha.item():.4f} D={model.D.item():.4f}")

    state["w"] = w_pde_final
    opt2 = torch.optim.LBFGS(params, lr=1.0, max_iter=lbfgs_iters, line_search_fn="strong_wolfe")

    def closure():
        opt2.zero_grad()
        L, _, _ = loss_fn()
        L.backward()
        return L
    opt2.step(closure)

    with torch.no_grad():
        L, lp, ld = loss_fn()
    info = dict(alpha=model.alpha.item(), D=model.D.item(),
                pde_rms=lp.sqrt().item(), data_misfit=ld.item(), loss=L.item())
    return model, info


if __name__ == "__main__":
    import argparse
    from frac_identification_baseline import forward, sigma_min, nls_fit
    ap = argparse.ArgumentParser()
    ap.add_argument("--res", default="l1", choices=["l1", "volterra"], help="lloji i humbjes se fizikes")
    ap.add_argument("--wfinal", type=float, default=1e6)
    ap.add_argument("--skip", type=float, default=0.05)
    ap.add_argument("--epochs", type=int, default=5000)
    ap.add_argument("--m", type=int, default=40)
    a = ap.parse_args()

    theta_true = np.array([0.6, 0.5])
    c = [1.0, 0.5, 0.25]
    m, sigma = a.m, 1e-2
    rng = np.random.default_rng(0)
    t_d = np.sort(rng.uniform(0.05, 1.0, m))
    x_d = rng.uniform(0.1, 0.9, m)
    y_d = forward(theta_true, x_d, t_d, np.array(c)) + sigma * rng.standard_normal(m)
    kw = dict(sigma=sigma, epochs=a.epochs, w_pde_final=a.wfinal, skip_frac=a.skip, res_type=a.res)
    print("konfigurimi:", kw, " m =", m)

    th_nls = nls_fit(y_d, x_d, t_d, np.array(c), np.array([0.5, 1.0]))
    print("NLS referencë:", th_nls, " gabimi relativ:", np.abs(th_nls - theta_true) / theta_true)

    results, models = [], []
    for a0 in (0.3, 0.5, 0.8):
        mdl, info = train(c, x_d, t_d, y_d, alpha_init=a0, verbose=False, **kw)
        results.append(info); models.append(mdl)
        print(f"alpha_init={a0}: {info}")
    best = min(results, key=lambda r: r["loss"])
    best_model = models[results.index(best)]
    th_hat = np.array([best["alpha"], best["D"]])
    print("Zgjedhur:", best, " e verteta:", theta_true)
    print("gabimi relativ:", np.abs(th_hat - theta_true) / theta_true)

    # CERTIFIKATA (blloku C): defekti Volterra i rrjetit; zgjidhesi spektral vetem per J dhe L
    from network_certificate import certify_specpinn
    cert = certify_specpinn(best_model, x_d, t_d, y_d, sigma)
    err = np.linalg.norm(th_hat - theta_true)
    print("CERTIFIKATA:", {k: (float(v) if np.ndim(v) == 0 else np.round(v, 5)) for k, v in cert.items()})
    print(f"gabimi i vertete ||theta_hat-theta*|| = {err:.4f};  kufi i certifikuar = {cert['bound']:.4f}")
