"""Reproduce the numbers of Section 5.9 (Tables 9 and 10) from the CSV files.
Usage (from the repository root):  python code/analyze_bias.py"""
import csv, os
import numpy as np
R = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")

def load(path):
    with open(os.path.join(R, path), newline="") as f:
        rows = list(csv.DictReader(f))
    return lambda k: np.array([float(r[k]) for r in rows])

def ms(v):
    return f"{v.mean():+.4f} ± {v.std(ddof=1) / np.sqrt(len(v)):.4f}"

print("Table 9: paired PINN − NLS, noisy data, w=1e6, m=40, trials 0–19")
for lab, f in [("skip 0.02, M 200", "bias_analysis/bias_s002.csv"), ("skip 0.03, M 200", "bias_analysis/bias_s003.csv"),
               ("skip 0.05, M 200", "ablations/abl_w1e6_s005.csv"), ("skip 0.05, M 400", "bias_analysis/bias_s005_M400.csv"),
               ("skip 0.10, M 200", "ablations/abl_w1e6.csv")]:
    g = load(f); da = g("pinn_a") - g("nls_a"); dD = g("pinn_D") - g("nls_D")
    rm = lambda e: np.sqrt(np.mean(e ** 2))
    print(f"  {lab}: dα {ms(da)} (median {np.median(da):+.4f})  dD {ms(dD)}  RMSE α {rm(g('pinn_a') - .6):.4f}/{rm(g('nls_a') - .6):.4f}")

print("\nTable 10: noise-free data, error w.r.t. θ*, m=40, w=1e5, skip=0.02, trials 0–9")
for lab, f in [("64x3, L-BFGS 300, start (0.5,1.0)", "nf_w1e5.csv"), ("64x3, L-BFGS 3000", "nf_lb3000.csv"),
               ("128x4, L-BFGS 300", "nf_w128d4.csv"), ("128x4, L-BFGS 3000", "nf_both.csv"),
               ("start (0.6,0.5)", "nf_init_true.csv"), ("start (0.5,0.5)", "nf_init_a05D05.csv"), ("start (0.7,1.0)", "nf_init_a07D1.csv"),
               ("w = 1e6", "nf_w1e6.csv"), ("w = 1e7", "nf_w1e7.csv")]:
    g = load("bias_analysis/" + f)
    print(f"  {lab}: α−α* {ms(g('pinn_a') - .6)}  D−D* {ms(g('pinn_D') - .5)}  residual {np.median(g('pinn_pde_rms')):.1e}  misfit {np.median(g('pinn_misfit')):.1e}")
