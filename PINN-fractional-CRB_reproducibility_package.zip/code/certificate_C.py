"""
Blloku C: certifikate a posteriori Gauss-Newton per ||theta_hat - theta*||_2.
Perdor zgjidhesin spektral te sakte (jo rrjetin). Verifikohet kundrejt CSV te experiment_B.

  Delta = theta* - theta_hat = J+ (y - F(theta_hat)) - J+ eps - J+ R,  ||R|| <= (L/2)||Delta||^2
  ||Delta|| <= a + kappa ||Delta||^2,   a = ||J+ r|| + q_eps,   kappa = L / (2 sigma_min(J))
  => ||Delta|| <= (1 - sqrt(1 - 4 kappa a)) / (2 kappa)   (rrenja e vogel; supozim: Delta ne fqinjesine e vlefshme)

Dy variante per ||J+ eps||:
  rigoroze : ||eps||/sigma_min, me ||eps|| <= sigma sqrt(m + 2 sqrt(m t) + 2 t), t = ln(1/delta)
  statistike (heuristike): sigma sqrt(chi2_{2,1-delta}) / sigma_min  (supozon J(theta_hat) ~ J(theta*))
L vleresohet numerikisht ne theta_hat (NUK eshte kufi rigoroz per L).
"""
import csv, sys
import numpy as np
from scipy.stats import chi2
from frac_identification_baseline import forward, jacobian
from experiment_B import make_data, C

def hessian_norm(theta, x, t, h=1e-3):
    th = np.asarray(theta, float)
    f = lambda a, d: forward(np.array([a, d]), x, t, C)
    a, d = th
    f00 = f(a, d)
    Haa = (f(a + h, d) - 2 * f00 + f(a - h, d)) / h ** 2
    HDD = (f(a, d + h) - 2 * f00 + f(a, d - h)) / h ** 2
    HaD = (f(a + h, d + h) - f(a + h, d - h) - f(a - h, d + h) + f(a - h, d - h)) / (4 * h ** 2)
    L = 0.0
    for ang in np.linspace(0, np.pi, 91):
        v1, v2 = np.cos(ang), np.sin(ang)
        L = max(L, np.linalg.norm(v1 ** 2 * Haa + 2 * v1 * v2 * HaD + v2 ** 2 * HDD))
    return L

def certificate(theta_hat, x, t, y, sigma, delta=0.05):
    m = len(y)
    r = y - forward(theta_hat, x, t, C)
    J = jacobian(theta_hat, x, t, C)
    smin = np.linalg.svd(J, compute_uv=False)[-1]
    g = np.linalg.norm(np.linalg.pinv(J) @ r)
    tt = np.log(1 / delta)
    q_rig = sigma * np.sqrt(m + 2 * np.sqrt(m * tt) + 2 * tt) / smin
    q_stat = sigma * np.sqrt(chi2.ppf(1 - delta, 2)) / smin
    L = hessian_norm(theta_hat, x, t)
    kappa = L / (2 * smin)
    def solve(a):
        disc = 1 - 4 * kappa * a
        return np.inf if disc <= 0 else (1 - np.sqrt(disc)) / (2 * kappa)
    return dict(g=g, smin=smin, L=L, b_rig=solve(g + q_rig), b_stat=solve(g + q_stat),
                lin_stat=g + q_stat)

def run(path, sigma=0.01, theta_true=(0.6, 0.5)):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        m, trial = int(r["m"]), int(r["trial"])
        x, t, y = make_data(m, sigma, 1000 * trial + m)
        th = np.array([float(r["pinn_a"]), float(r["pinn_D"])])
        c = certificate(th, x, t, y, sigma)
        c["err"] = np.linalg.norm(th - np.array(theta_true))
        out.append(c)
    e = np.array([o["err"] for o in out])
    br = np.array([o["b_rig"] for o in out]); bs = np.array([o["b_stat"] for o in out])
    print(f"{path.split('/')[-1]:18s} n={len(out)} | err mediane={np.median(e):.4f} | "
          f"rigoroze: mbulim={np.mean(e<=br):.2f} kufi/err={np.median(br/e):.1f}x | "
          f"statistike: mbulim={np.mean(e<=bs):.2f} kufi/err={np.median(bs/e):.1f}x | "
          f"sigma_min med={np.median([o['smin'] for o in out]):.2f} L med={np.median([o['L'] for o in out]):.1f}")

if __name__ == "__main__":
    for p in sys.argv[1:]:
        run(p)
