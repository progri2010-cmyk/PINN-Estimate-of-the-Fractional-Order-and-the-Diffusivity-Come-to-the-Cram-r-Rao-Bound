"""Merge experiment_B CSV files. Usage: python merge_csv.py out.csv a.csv b.csv ...
Keeps the union of columns (older files have no code_version column); duplicates (sigma, m, trial) keep the first."""
import csv, sys
out, files = sys.argv[1], sys.argv[2:]
rows, fields = [], []
for f in files:
    with open(f, newline="") as fh:
        r = csv.DictReader(fh)
        fields += [c for c in r.fieldnames if c not in fields]
        rows += list(r)
rows.sort(key=lambda x: (float(x["sigma"]), int(x["m"]), int(x["trial"])))
seen = set(); uniq = []
for x in rows:
    k = (x["sigma"], x["m"], x["trial"])
    if k not in seen:
        seen.add(k); uniq.append(x)
with open(out, "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=fields, restval=""); w.writeheader(); w.writerows(uniq)
print(len(uniq), "rows ->", out)
