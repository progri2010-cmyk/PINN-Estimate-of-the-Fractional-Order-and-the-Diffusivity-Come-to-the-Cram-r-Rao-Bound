"""
Baseline per identifikimin e (alpha, D) ne ekuacionin Caputo nen-difuziv:
    d_t^alpha u = D u_xx,  u(0,t)=u(1,t)=0,  u(x,0)=u0(x)
Permban: Mittag-Leffler E_alpha(-x), zgjidhje spektrale (e vertete themelore),
Jakobiani, sigma_min(J), katroret me te vegjel jolinear (NLS), eksperiment Monte Carlo.
"""
import numpy as np
from scipy.integrate import quad
from scipy.optimize import least_squares

# ---------- Mittag-Leffler E_alpha(-x), x>=0, 0<alpha<1 ----------
def ml_neg(alpha, x):
    """E_alpha(-x) nga paraqitja integrale (Gorenflo-Mainardi), e vlefshme per 0<alpha<1."""
    if x < 1e-12:
        return 1.0
    th = np.pi * alpha
    f = lambda s: np.exp(-(s * x) ** (1.0 / alpha)) / (s * s + 2 * s * np.cos(th) + 1.0)
    smax = 60.0 ** alpha / x          # (s x)^(1/alpha) = 60 -> exp(-60) ~ 0
    val, _ = quad(f, 0, smax, limit=200, epsabs=1e-13, epsrel=1e-12,
                  points=[min(1.0, smax / 2)] if smax > 1 else None)
    return np.sin(th) / th * val

def ml_vec(alpha, X):
    X = np.asarray(X, float)
    return np.array([ml_neg(alpha, x) for x in X.ravel()]).reshape(X.shape)

# ---------- zgjidhja spektrale ----------
def u_exact(x, t, alpha, D, c, N=None):
    """u(x,t) = sum_n c_n E_alpha(-D lam_n t^alpha) phi_n(x);  c = koeficientet (c_1..c_N)."""
    c = np.atleast_1d(c)
    N = len(c) if N is None else N
    x = np.atleast_1d(x); t = np.atleast_1d(t)
    out = np.zeros(len(x))
    for n in range(1, N + 1):
        lam = (n * np.pi) ** 2
        phi = np.sqrt(2) * np.sin(n * np.pi * x)
        out += c[n - 1] * ml_vec(alpha, D * lam * t ** alpha) * phi
    return out

def forward(theta, xs, ts, c):
    return u_exact(xs, ts, theta[0], theta[1], c)

# ---------- Jakobiani dhe sigma_min ----------
def jacobian(theta, xs, ts, c, h=(1e-5, 1e-5)):
    th = np.asarray(theta, float)
    J = np.zeros((len(xs), 2))
    for j in range(2):
        e = np.zeros(2); e[j] = h[j]
        J[:, j] = (forward(th + e, xs, ts, c) - forward(th - e, xs, ts, c)) / (2 * h[j])
    return J

def sigma_min(theta, xs, ts, c):
    return np.linalg.svd(jacobian(theta, xs, ts, c), compute_uv=False)[-1]

# ---------- NLS baseline ----------
def nls_fit(y, xs, ts, c, theta0, bounds=((0.05, 1e-3), (0.98, 10.0))):
    res = least_squares(lambda th: forward(th, xs, ts, c) - y, theta0, bounds=bounds,
                        x_scale=[0.1, 0.1], xtol=1e-12, ftol=1e-12)
    return res.x

# ---------- eksperimenti Monte Carlo ----------
def monte_carlo(theta_true, m, sigma, c, T=1.0, t_min=0.05, trials=50, seed=0,
                x_loc="spread"):
    rng = np.random.default_rng(seed)
    errs = []
    for _ in range(trials):
        ts = np.sort(rng.uniform(t_min, T, m))
        xs = rng.uniform(0.1, 0.9, m) if x_loc == "spread" else np.full(m, 0.5)
        y = forward(theta_true, xs, ts, c) + sigma * rng.standard_normal(m)
        th0 = np.array([rng.uniform(0.3, 0.9), rng.uniform(0.1, 2.0)])  # inicializim i rastit
        try:
            errs.append(nls_fit(y, xs, ts, c, th0) - theta_true)
        except Exception:
            errs.append(np.array([np.nan, np.nan]))
    errs = np.array(errs)
    return np.sqrt(np.nanmean(errs ** 2, axis=0)), np.mean(np.isnan(errs[:, 0]))

if __name__ == "__main__":
    theta_true = np.array([0.6, 0.5])
    c = np.array([1.0, 0.5, 0.25])               # u0 me 3 mode
    # (i) harta e sigma_min per dy dritare kohore
    for tmin in (0.01, 0.1, 0.5):
        ts = np.linspace(tmin, 1.0, 20); xs = np.full(20, 0.3)
        print(f"t_min={tmin}: sigma_min(J) = {sigma_min(theta_true, xs, ts, c):.4f}")
    # (ii) RMSE kundrejt m dhe sigma, krahasim me CRB
    for sigma in (0.001, 0.01):
        for m in (5, 10, 20, 40):
            rmse, fail = monte_carlo(theta_true, m, sigma, c, trials=30)
            print(f"sigma={sigma}, m={m}: RMSE(alpha,D)={rmse}, fail={fail:.2f}")
