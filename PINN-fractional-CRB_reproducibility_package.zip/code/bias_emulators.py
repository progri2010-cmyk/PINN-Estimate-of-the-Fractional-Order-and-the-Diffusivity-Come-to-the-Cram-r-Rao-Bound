"""
Section 5.9 diagnostics (NumPy/SciPy only): minimize the SAME discrete loss as pinn_spectral.py
(L1 operator, skip window, normalization 1/(1+D*lambda_n), weights w and 1/sigma^2) with the network
replaced by a linear representation of the modal coefficients a_n:

  grid   : free values a_n(t_k) on the L1 grid, 4-point Lagrange interpolation in s=t^alpha to the data times
  cheb   : a_n(s) = c_n + s * sum_{k<=deg} p_nk T_k(2s-1)   (smooth in s, like the network)

For fixed theta the loss is quadratic -> exact linear least squares; theta is found by profiling (Nelder-Mead).

Usage:
  python bias_emulators.py --rep grid  --trials 0 1 2                       # noise-free, M=200, skip=0.02, w=1e5
  python bias_emulators.py --rep cheb  --trials 0 1 2 --M 400
  python bias_emulators.py --rep cheb  --trials 100 101 --noise 1 --cert    # noisy data: overfits; Volterra certificate
"""
import argparse, math
import numpy as np
from math import gamma, pi, sqrt
from scipy.optimize import minimize
from experiment_B import make_data, C, THETA

K = 3
LAM = (np.arange(1, K + 1) * pi) ** 2


def l1_matrix(M, tau, a):
    """(L u)_n = L1 Caputo approximation at t_n, n=1..M; shape (M, M+1)."""
    b = (np.arange(M) + 1.0) ** (1 - a) - np.arange(M) ** (1 - a)
    L = np.zeros((M, M + 1))
    for n in range(1, M + 1):
        for k in range(n):
            L[n - 1, k + 1] += b[n - k - 1]
            L[n - 1, k] -= b[n - k - 1]
    return L * tau ** (-a) / gamma(2 - a)


def lagrange_matrix(tg, td, a, order=4):
    sg, sd = tg ** a, td ** a
    P = np.zeros((len(td), len(tg)))
    for i, s in enumerate(sd):
        j = np.searchsorted(sg, s)
        lo = max(0, min(len(sg) - order, j - order // 2))
        idx = np.arange(lo, lo + order)
        for q in idx:
            P[i, q] = np.prod([(s - sg[r]) / (sg[q] - sg[r]) for r in idx if r != q])
    return P


def cheb_basis(s, deg):
    return s[:, None] * np.polynomial.chebyshev.chebvander(2 * s - 1, deg)


def build(theta, x, t, y, sigma, M, skip, w, rep, deg):
    """Return (A, b, Ares, bres, Adat, bdat, coeff_map) of the weighted linear LS problem."""
    a, D = theta
    tg = np.linspace(0, 1, M + 1)
    L = l1_matrix(M, 1.0 / M, a)
    n0 = max(1, int(skip * M)); rows = slice(n0 - 1, M)
    Nr = K * (M - n0 + 1); m = len(y)
    phi = np.sqrt(2) * np.sin(pi * np.outer(x, np.arange(1, K + 1)))
    if rep == "grid":
        nb = M
        G = np.vstack([np.zeros((1, M)), np.eye(M)])            # grid values at t_0..t_M from unknowns t_1..t_M
        g0 = np.zeros(M + 1); g0[0] = 1.0                      # a(t_0) = c_n
        Pd = lagrange_matrix(tg, t, a)
        Bg, Bd, off_g, off_d = G, Pd @ G, g0, Pd @ g0
    else:
        nb = deg + 1
        Bg, Bd = cheb_basis(tg ** a, deg), cheb_basis(t ** a, deg)
        off_g, off_d = np.ones(M + 1), np.ones(len(t))           # a = c_n + s*sum(...)
    Ar = np.zeros((Nr, K * nb)); br = np.zeros(Nr); r0 = 0
    for n in range(K):
        Op = ((L + D * LAM[n] * np.eye(M + 1)[1:]) / (1 + D * LAM[n]))[rows]
        nr = Op.shape[0]
        Ar[r0:r0 + nr, n * nb:(n + 1) * nb] = Op @ Bg
        br[r0:r0 + nr] = -(Op @ off_g) * C[n]
        r0 += nr
    Ad = np.zeros((m, K * nb)); bd = y.astype(float).copy()
    for n in range(K):
        Ad[:, n * nb:(n + 1) * nb] = phi[:, [n]] * Bd
        bd -= phi[:, n] * off_d * C[n]
    sw, sd = sqrt(w / Nr), sqrt(1.0 / (m * sigma ** 2))
    A = np.vstack([sw * Ar, sd * Ad]); b = np.concatenate([sw * br, sd * bd])
    return A, b, Ar, br, Ad, bd, (Bg, nb)


def solve(theta, *args):
    A, b, Ar, br, Ad, bd, _ = build(theta, *args)
    p, *_ = np.linalg.lstsq(A, b, rcond=None)
    return p, A @ p - b, Ar @ p - br, Ad @ p - bd


def fit(x, t, y, sigma, M, skip, w, rep, deg):
    to_theta = lambda z: (0.05 + 0.93 / (1 + np.exp(-z[0])), np.exp(z[1]))
    f = lambda z: float(np.sum(solve(to_theta(z), x, t, y, sigma, M, skip, w, rep, deg)[1] ** 2))
    p0 = (0.6 - 0.05) / 0.93
    r = minimize(f, [np.log(p0 / (1 - p0)), np.log(0.5)], method="Nelder-Mead",
                 options=dict(xatol=1e-8, fatol=1e-14, maxiter=600))
    th = np.array(to_theta(r.x))
    p, _, rres, rdat = solve(th, x, t, y, sigma, M, skip, w, rep, deg)
    return th, p, np.sqrt(np.mean(rres ** 2)), np.mean(rdat ** 2) / sigma ** 2


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rep", choices=["grid", "cheb"], default="cheb")
    ap.add_argument("--trials", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--m", type=int, default=40)
    ap.add_argument("--sigma", type=float, default=0.01)
    ap.add_argument("--noise", type=float, default=0.0, help="0 = noise-free data (sigma is only the misfit weight)")
    ap.add_argument("--M", type=int, default=200)
    ap.add_argument("--skip", type=float, default=0.02)
    ap.add_argument("--w", type=float, default=1e5)
    ap.add_argument("--deg", type=int, default=20)
    ap.add_argument("--cert", action="store_true", help="Volterra-defect certificate of the fitted representation (cheb only)")
    a = ap.parse_args()
    print("config:", vars(a))
    for tr in a.trials:
        x, t, y = make_data(a.m, a.sigma, 1000 * tr + a.m, a.noise)
        th, p, pde, mis = fit(x, t, y, a.sigma, a.M, a.skip, a.w, a.rep, a.deg)
        line = f"trial {tr}: theta-theta* = {np.round(th - THETA, 5)}  residual {pde:.1e}  misfit {mis:.1e}"
        if a.cert and a.rep == "cheb":
            from network_certificate import network_certificate
            P = p.reshape(K, a.deg + 1)
            af = lambda tt, P=P, al=th[0]: C[None, :] + cheb_basis(np.asarray(tt, float) ** al, a.deg) @ P.T
            c = network_certificate(af, C, th, x, t, y, a.sigma)
            line += f"  bound {c['bound']:.4f}  eta {c['eta']:.2e}  max|theta_n| {np.round(c['defect_max'], 4)}"
        print(line, flush=True)
