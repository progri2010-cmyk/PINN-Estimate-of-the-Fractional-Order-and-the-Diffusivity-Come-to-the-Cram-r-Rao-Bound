"""
Baseline fPINN (Pang-Lu-Karniadakis): MLP e plote u(x,t), alpha dhe D te trajnueshme,
derivat Caputo me L1, u_xx me diferencim automatik. Pa baze spektrale.

Dallimi nga PINN spektral: rrjeti mëson edhe strukturen ne x.
  feature="t"      -> hyrja (x, t), faktori i IC/BC t*x(1-x)      (fPINN standard)
  feature="talpha" -> hyrja (x, t^alpha), faktori t^alpha x(1-x)  (me njohuri te singularitetit; si pinn_alpha_D)
IC dhe BC te forcuara:  u = u0(x) + tau * x(1-x) * N(x, tau).

Trajnimi eshte i njejti me pinn_spectral.train: vazhdim penaliteti w_pde -> w_pde_final, Adam me ulje te lr, pastaj L-BFGS;
mbetja L1 vetem per t >= skip_frac*T. Ndahet me train() te spektralit ndersa buxheti (epokat) eshte parameter.
STATUSI: pjesa PyTorch nuk eshte ekzekutuar ne mjedisin ku u shkrua; l1_caputo dhe pde_residual jane ripërdorur nga pinn_alpha_D
(te ekzekutuara ne makinen tuaj).
"""
import math
import torch
from pinn_alpha_D import PINN, pde_residual, u0_fn

torch.set_default_dtype(torch.float64)


class FPINN(PINN):
    def __init__(self, c, feature="t", width=64, depth=4, **kw):
        super().__init__(c, width=width, depth=depth, **kw)
        self.feature = feature

    def u(self, x, t):
        tau = t ** self.alpha if self.feature == "talpha" else t
        h = self.net(torch.stack([x, tau], dim=-1)).squeeze(-1)
        return u0_fn(x, self.c) + tau * x * (1 - x) * h


def train_fpinn(c, x_d, t_d, y_d, T=1.0, M=200, Nx=32, sigma=1e-2, epochs=5000, lbfgs_iters=300,
                lr=2e-3, w_pde=100.0, w_pde_final=1e6, w_data=1.0, skip_frac=0.05, alpha_init=0.5,
                D_init=1.0, seed=0, feature="t", verbose=False, res_type=None, width=64, depth=4,
                theta_fixed=None, **_ignored):
    torch.manual_seed(seed)
    if theta_fixed is not None:          # diagnostike: problemi i drejte me (alpha, D) te dhena
        alpha_init, D_init = theta_fixed
    model = FPINN(c, feature=feature, width=width, depth=depth, alpha_init=alpha_init, D_init=D_init)
    if theta_fixed is not None:
        model.a_raw.requires_grad_(False); model.logD.requires_grad_(False)
    xs = torch.linspace(0.02, 0.98, Nx)
    x_d, t_d, y_d = [torch.as_tensor(a, dtype=torch.float64) for a in (x_d, t_d, y_d)]
    params = [q for q in model.parameters() if q.requires_grad]
    state = {"w": w_pde}

    def loss_fn():
        r = pde_residual(model, xs, T, M, skip_frac)
        l_pde = (r ** 2).mean()
        l_dat = ((model.u(x_d, t_d) - y_d) ** 2).mean() / sigma ** 2
        return state["w"] * l_pde + w_data * l_dat, l_pde, l_dat

    opt = torch.optim.Adam(params, lr=lr)
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.5 ** (1.0 / max(1, epochs // 4)))
    for ep in range(epochs):
        state["w"] = w_pde * (w_pde_final / w_pde) ** (ep / max(1, epochs - 1))
        opt.zero_grad()
        L, lp, ld = loss_fn()
        L.backward()
        opt.step()
        sched.step()
        if verbose and ep % 1000 == 0:
            print(f"  ep {ep:5d} L={L.item():.3e} pde={lp.item():.3e} dat={ld.item():.3e} "
                  f"alpha={model.alpha.item():.4f} D={model.D.item():.4f}")
    state["w"] = w_pde_final
    opt2 = torch.optim.LBFGS(params, lr=1.0, max_iter=lbfgs_iters, line_search_fn="strong_wolfe")

    def closure():
        opt2.zero_grad()
        L, _, _ = loss_fn()
        L.backward()
        return L
    opt2.step(closure)
    L, lp, ld = loss_fn()
    info = dict(alpha=model.alpha.item(), D=model.D.item(), pde_rms=lp.detach().sqrt().item(),
                data_misfit=ld.detach().item(), loss=L.detach().item())
    return model, info
