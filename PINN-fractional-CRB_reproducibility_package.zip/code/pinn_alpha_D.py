"""
PINN per identifikimin e (alpha, D) ne  d_t^alpha u = D u_xx,  u(0,t)=u(1,t)=0,  u(x,0)=u0(x).

Dizajni:
  * hyrja e rrjetit eshte (x, s) me s = t^alpha  -> singulariteti t^alpha ne t=0 behet i lemuar ne s
  * IC dhe BC te forcuara ne ansatz:  u = u0(x) + s * x(1-x) * N(x, s)
  * derivati Caputo me skemen L1 ne rrjet uniform kohor (peshat varen nga alpha, diferencueshem)
  * u_xx me diferencim automatik
  * alpha = a_lo + (a_hi-a_lo)*sigmoid(a_raw),  D = exp(logD)

STATUSI: koda e trajnimit NUK eshte ekzekutuar ne mjedisin ku u shkrua (pa PyTorch).
Skema L1 dhe ansatz-i u verifikuan veçmas me NumPy kunder zgjidhjes se sakte.
Duhet ekzekutuar dhe rregulluar (lr, epoka, peshat) ne makinen tuaj.
"""
import math
import numpy as np
import torch
import torch.nn as nn

torch.set_default_dtype(torch.float64)


def u0_fn(x, c):
    """u0 = sum c_n sqrt(2) sin(n pi x)  (c: lista e koeficienteve)."""
    out = torch.zeros_like(x)
    for n, cn in enumerate(c, start=1):
        out = out + cn * math.sqrt(2.0) * torch.sin(n * math.pi * x)
    return out


class PINN(nn.Module):
    def __init__(self, c, width=48, depth=4, alpha_init=0.5, D_init=1.0,
                 a_lo=0.05, a_hi=0.98):
        super().__init__()
        self.c, self.a_lo, self.a_hi = c, a_lo, a_hi
        layers, d_in = [], 2
        for _ in range(depth):
            layers += [nn.Linear(d_in, width), nn.Tanh()]
            d_in = width
        layers += [nn.Linear(d_in, 1)]
        self.net = nn.Sequential(*layers)
        p = (alpha_init - a_lo) / (a_hi - a_lo)
        self.a_raw = nn.Parameter(torch.tensor(math.log(p / (1 - p))))
        self.logD = nn.Parameter(torch.tensor(math.log(D_init)))

    @property
    def alpha(self):
        return self.a_lo + (self.a_hi - self.a_lo) * torch.sigmoid(self.a_raw)

    @property
    def D(self):
        return torch.exp(self.logD)

    def u(self, x, t):
        s = t ** self.alpha
        h = self.net(torch.stack([x, s], dim=-1)).squeeze(-1)
        return u0_fn(x, self.c) + s * x * (1 - x) * h


def l1_caputo(U, tau, alpha):
    """U: (Nx, M+1) vlera ne t_k = k*tau. Kthen d_t^alpha U ne t_1..t_M, forme (Nx, M)."""
    M = U.shape[1] - 1
    dU = U[:, 1:] - U[:, :-1]                                   # (Nx, M)
    j = torch.arange(0, M, dtype=U.dtype)
    b = (j + 1) ** (1 - alpha) - j ** (1 - alpha)               # (M,)
    pref = tau ** (-alpha) / torch.exp(torch.lgamma(2 - alpha))
    out = []
    for n in range(1, M + 1):                                   # t_n
        w = b[:n].flip(0)                                       # b_{n-k-1}, k=0..n-1
        out.append((dU[:, :n] * w).sum(dim=1))
    return pref * torch.stack(out, dim=1)


def pde_residual(model, xs, T, M, skip_frac=0.1):
    """Mbetja PDE ne rrjetin (xs x {t_n}), vetem per t_n >= skip_frac*T.
    Arsyeja: L1 ne rrjet uniform ka gabim strukturor afer t=0 (zgjidhja ~ t^alpha);
    verifikuar numerikisht: RMS i mbetjes se zgjidhjes se sakte ~0.31 (M=100) mbi gjithe
    intervalin, por ~0.004 per t>0.1. Informacionin per alpha afer t=0 e mbajne te dhenat."""
    tau = T / M
    t_grid = torch.linspace(0.0, T, M + 1)
    X = xs[:, None].expand(-1, M + 1).clone().requires_grad_(True)
    Tt = t_grid[None, :].expand(xs.shape[0], -1)
    U = model.u(X, Tt)
    ux = torch.autograd.grad(U.sum(), X, create_graph=True)[0]
    uxx = torch.autograd.grad(ux.sum(), X, create_graph=True)[0]
    cap = l1_caputo(U, tau, model.alpha)
    n0 = max(1, int(skip_frac * M))
    return (cap - model.D * uxx[:, 1:])[:, n0 - 1:]


def train(c, x_d, t_d, y_d, T=1.0, M=100, Nx=32, sigma=1e-2,
          adam_epochs=3000, lbfgs_iters=300, lr=2e-3, w_pde=1.0, w_data=1.0,
          alpha_init=0.5, D_init=1.0, seed=0, verbose=True, theta_fixed=None):
    torch.manual_seed(seed)
    if theta_fixed is not None:          # diagnostike: problemi i drejte me (alpha, D) te dhena
        alpha_init, D_init = theta_fixed
    model = PINN(c, alpha_init=alpha_init, D_init=D_init)
    if theta_fixed is not None:
        model.a_raw.requires_grad_(False)
        model.logD.requires_grad_(False)
    params = [q for q in model.parameters() if q.requires_grad]
    xs = torch.linspace(0.02, 0.98, Nx)
    x_d, t_d, y_d = [torch.as_tensor(a, dtype=torch.float64) for a in (x_d, t_d, y_d)]

    def loss_fn():
        r = pde_residual(model, xs, T, M)
        l_pde = (r ** 2).mean()
        l_dat = ((model.u(x_d, t_d) - y_d) ** 2).mean() / sigma ** 2
        return w_pde * l_pde + w_data * l_dat, l_pde, l_dat

    opt = torch.optim.Adam(params, lr=lr)
    for ep in range(adam_epochs):
        opt.zero_grad()
        L, lp, ld = loss_fn()
        L.backward()
        opt.step()
        if verbose and ep % 500 == 0:
            print(f"ep {ep:5d} L={L.item():.3e} pde={lp.item():.3e} dat={ld.item():.3e} "
                  f"alpha={model.alpha.item():.4f} D={model.D.item():.4f}")

    opt2 = torch.optim.LBFGS(params, lr=1.0, max_iter=lbfgs_iters,
                             line_search_fn="strong_wolfe")

    def closure():
        opt2.zero_grad()
        L, _, _ = loss_fn()
        L.backward()
        return L
    opt2.step(closure)

    with torch.no_grad():
        pass
    r = pde_residual(model, xs, T, M)
    info = dict(alpha=model.alpha.item(), D=model.D.item(),
                pde_rms=r.pow(2).mean().sqrt().item())
    return model, info


if __name__ == "__main__":
    from frac_identification_baseline import forward, sigma_min

    theta_true = np.array([0.6, 0.5])
    c = [1.0, 0.5, 0.25]
    m, sigma = 20, 1e-2
    rng = np.random.default_rng(0)
    t_d = np.sort(rng.uniform(0.05, 1.0, m))
    x_d = rng.uniform(0.1, 0.9, m)
    y_d = forward(theta_true, x_d, t_d, np.array(c)) + sigma * rng.standard_normal(m)

    # DIAGNOSTIKE 1: alpha, D te fiksuara ne vlerat e sakta -> a mesohet zgjidhja?
    # Pritja: pde_rms zbret ne rreth 1e-2 ose me poshte (dyshemeja e L1 ~4e-3).
    _, info0 = train(c, x_d, t_d, y_d, sigma=sigma, theta_fixed=tuple(theta_true))
    print("DIAGNOSTIKE (theta fikse):", info0)

    # DIAGNOSTIKE 2: identifikimi i plote
    model, info = train(c, x_d, t_d, y_d, sigma=sigma)
    print("PINN:", info, " e verteta:", theta_true)
    th_hat = np.array([info["alpha"], info["D"]])
    print("sigma_min(J(theta_hat)) =", sigma_min(th_hat, x_d, t_d, np.array(c)))
    print("gabimi relativ:", np.abs(th_hat - theta_true) / theta_true)
