"""
Diagnostike per fPINN: a e mëson rrjeti PROBLEMIN E DREJTE kur alpha, D jane te fiksuara ne vlerat e sakta?
Mat gabimin e zgjidhjes kundrejt zgjidhjes spektrale te sakte ne nje rrjet testimi (x,t).
Perdorimi:  python fpinn_diag.py --feature talpha --wfinal 1e6 --epochs 5000 --width 64
Interpretimi: gabimi relativ L2 i zgjidhjes <~1e-2 => mesohet; >>1e-2 => dështim i perfaqesimit/optimizimit (jo i identifikimit).
"""
import argparse, time
import numpy as np
from frac_identification_baseline import forward
from experiment_B import make_data, C, THETA

ap = argparse.ArgumentParser()
ap.add_argument("--feature", default="talpha", choices=["t", "talpha"])
ap.add_argument("--wfinal", type=float, default=1e6)
ap.add_argument("--epochs", type=int, default=5000)
ap.add_argument("--width", type=int, default=64)
ap.add_argument("--depth", type=int, default=4)
ap.add_argument("--Nx", type=int, default=32)
ap.add_argument("--m", type=int, default=20)
ap.add_argument("--sigma", type=float, default=0.03)
a = ap.parse_args()

import torch
from fpinn_baseline import train_fpinn

x, t, y = make_data(a.m, a.sigma, 1000 * 200 + a.m)
t0 = time.time()
model, info = train_fpinn(list(C), x, t, y, sigma=a.sigma, epochs=a.epochs, w_pde_final=a.wfinal, Nx=a.Nx,
                          feature=a.feature, width=a.width, depth=a.depth, theta_fixed=tuple(THETA), verbose=True)
xs = np.linspace(0.1, 0.9, 9); ts = np.array([0.05, 0.1, 0.25, 0.5, 1.0])
X, T = np.meshgrid(xs, ts, indexing="ij"); X = X.ravel(); T = T.ravel()
u_ex = forward(THETA, X, T, C)
with torch.no_grad():
    u_nn = model.u(torch.as_tensor(X), torch.as_tensor(T)).numpy()
rel = np.linalg.norm(u_nn - u_ex) / np.linalg.norm(u_ex)
print(f"config: feature={a.feature} wfinal={a.wfinal:g} epochs={a.epochs} width={a.width} depth={a.depth} Nx={a.Nx}")
print(f"info: {info}")
print(f"gabimi relativ L2 i zgjidhjes (alpha,D te sakta): {rel:.3e};  max|err| = {np.abs(u_nn-u_ex).max():.3e};  koha {time.time()-t0:.0f}s")
