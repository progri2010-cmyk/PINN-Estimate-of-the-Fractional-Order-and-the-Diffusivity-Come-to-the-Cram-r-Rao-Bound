"""
Krahasim i çiftuar i ekzekutimeve nga CSV, i grupuar per (sigma, m).
Perdorimi:  python compare_runs.py val_m40.csv val_m10_20.csv ...
Per cdo (sigma,m): RMSE(PINN), raporti PINN/NLS me IK 95% (bootstrap mbi trial-et).
Nga skedari i dyte e tutje, per trial-et e perbashketa me skedarin e pare: raporti baze/ky me IK 95%.
"""
import csv, sys
import numpy as np

TH = {"a": 0.6, "D": 0.5}

def load(p):
    with open(p, newline="") as f:
        rows = list(csv.DictReader(f))
    return {(float(r["sigma"]), int(r["m"]), int(r["trial"])): r for r in rows}

def errs(rows, keys, col, true):
    return np.array([float(rows[k][col]) - true for k in keys])

def rmse(e):
    return np.sqrt(np.nanmean(e ** 2))

def boot(fn, n, B=4000, seed=0):
    rng = np.random.default_rng(seed)
    v = [fn(rng.integers(0, n, n)) for _ in range(B)]
    return np.nanpercentile(v, [2.5, 97.5])

files = sys.argv[1:]
base = load(files[0])
for p in files:
    cur = load(p)
    print(f"\n{p}")
    groups = sorted({(s, m) for (s, m, _) in cur})
    for (s, m) in groups:
        keys = sorted(k for k in cur if k[0] == s and k[1] == m)
        n = len(keys)
        print(f"  sigma={s:g} m={m} (n={n})")
        for q in ("a", "D"):
            e_p = errs(cur, keys, f"pinn_{q}", TH[q]); e_n = errs(cur, keys, f"nls_{q}", TH[q])
            ci = boot(lambda i: rmse(e_p[i]) / rmse(e_n[i]), n)
            line = f"    {q}: RMSE(PINN)={rmse(e_p):.4f}  RMSE(NLS)={rmse(e_n):.4f}  PINN/NLS={rmse(e_p)/rmse(e_n):.2f} [{ci[0]:.2f}, {ci[1]:.2f}]"
            common = [k for k in keys if k in base]
            if p != files[0] and len(common) >= 5:
                e_c = errs(cur, common, f"pinn_{q}", TH[q]); e_b = errs(base, common, f"pinn_{q}", TH[q])
                cb = boot(lambda i: rmse(e_b[i]) / rmse(e_c[i]), len(common))
                line += f"  | baze/ky={rmse(e_b)/rmse(e_c):.2f} [{cb[0]:.2f}, {cb[1]:.2f}] (n={len(common)})"
            print(line)
