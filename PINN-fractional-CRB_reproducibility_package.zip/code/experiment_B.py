"""
Blloku B: RMSE kundrejt (sigma, m) per NLS (spektral), PINN spektral, dhe kufirin Cramer-Rao.

Perdorimi:
    python experiment_B.py --trials 20 --ms 10 20 40 --sigmas 0.01 --out results_B.csv
    python experiment_B.py --no-pinn ...         # vetem NLS + CRB (pa PyTorch)
    python experiment_B.py --summarize results_B.csv

Rezultatet ruhen rresht pas rreshti; nese ndalohet, rifillon pa perseritur rreshta te kryer.
Per te dhenat e te njejtit (sigma, m, trial) perdoret i njejti seed -> krahasim i drejte.
"""
import argparse, csv, hashlib, os, subprocess, time
import numpy as np

from frac_identification_baseline import forward, jacobian, nls_fit

THETA = np.array([0.6, 0.5])
C = np.array([1.0, 0.5, 0.25])
FIELDS = ["sigma", "m", "trial", "nls_a", "nls_D", "crb_a", "crb_D",
          "pinn_a", "pinn_D", "pinn_pde_rms", "pinn_misfit", "pinn_time", "pinn_start", "code_version"]


def code_version():
    """Short git commit if available, otherwise a SHA-256 of the core source files (first 12 hex digits)."""
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        out = subprocess.run(["git", "rev-parse", "--short=12", "HEAD"], cwd=here, capture_output=True, text=True, timeout=5)
        if out.returncode == 0 and out.stdout.strip():
            return "git-" + out.stdout.strip()
    except Exception:
        pass
    h = hashlib.sha256()
    for name in ("experiment_B.py", "pinn_spectral.py", "fpinn_baseline.py", "frac_identification_baseline.py", "pinn_alpha_D.py"):
        fp = os.path.join(here, name)
        if os.path.exists(fp):
            with open(fp, "rb") as fh:
                h.update(fh.read())
    return "sha-" + h.hexdigest()[:12]


CODE_VERSION = code_version()


def make_data(m, sigma, seed, noise_scale=1.0):
    rng = np.random.default_rng(seed)
    t = np.sort(rng.uniform(0.05, 1.0, m))
    x = rng.uniform(0.1, 0.9, m)
    # noise_scale=0 -> te dhena pa zhurme (sigma mbetet vetem si peshe ne humbje)
    y = forward(THETA, x, t, C) + noise_scale * sigma * rng.standard_normal(m)
    return x, t, y


def done_keys(path):
    if not os.path.exists(path):
        return set()
    with open(path, newline="") as f:
        return {(float(r["sigma"]), int(r["m"]), int(r["trial"])) for r in csv.DictReader(f)}


def run(args):
    print("konfigurimi:", vars(args), "code_version:", CODE_VERSION, flush=True)
    new = not os.path.exists(args.out)
    done = done_keys(args.out)
    fields = FIELDS
    if not new:   # append to an older CSV: keep its header (older files have no code_version column)
        with open(args.out, newline="") as fh:
            fields = next(csv.reader(fh))
    if not args.no_pinn:
        if args.model == "fpinn":
            from fpinn_baseline import train_fpinn as train
            extra = dict(feature=args.feature)
        else:
            from pinn_spectral import train
            import inspect
            if "width" not in inspect.signature(train).parameters:
                raise SystemExit("GABIM: pinn_spectral.py eshte versioni i vjeter (pa width/depth). Kopjo versionin e ri.")
            extra = dict(width=args.width, depth=args.depth, lbfgs_iters=args.lbfgs)
    with open(args.out, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        if new:
            w.writeheader()
        for sigma in args.sigmas:
            for m in args.ms:
                for trial in range(args.offset, args.offset + args.trials):
                    if (sigma, m, trial) in done:
                        continue
                    seed = 1000 * trial + m
                    x, t, y = make_data(m, sigma, seed, args.noise_scale)
                    row = dict(sigma=sigma, m=m, trial=trial, code_version=CODE_VERSION)
                    try:
                        th = nls_fit(y, x, t, C, np.array([0.5, 1.0]))
                    except Exception:
                        th = np.array([np.nan, np.nan])
                    row["nls_a"], row["nls_D"] = th
                    J = jacobian(THETA, x, t, C)
                    cov = sigma ** 2 * np.linalg.inv(J.T @ J)
                    row["crb_a"], row["crb_D"] = np.sqrt(np.diag(cov))
                    if not args.no_pinn:
                        t0 = time.time()
                        starts = args.starts if args.starts else [args.alpha0]
                        best = None
                        for a0 in starts:                       # multistart, zgjedhje sipas humbjes finale
                            try:
                                _, info = train(list(C), x, t, y, sigma=sigma, epochs=args.epochs, M=args.M,
                                                w_pde_final=args.wfinal, skip_frac=args.skip, res_type=args.res,
                                                alpha_init=a0, D_init=args.D0, seed=seed, verbose=False, **extra)
                                if best is None or info["loss"] < best[0]["loss"]:
                                    best = (info, a0)
                            except Exception:
                                import traceback
                                traceback.print_exc()
                        if best is None:
                            raise SystemExit("GABIM: te gjitha nisjet deshtuan (shih traceback me siper); rreshti NUK u shkrua.")
                            row.update(pinn_a=np.nan, pinn_D=np.nan, pinn_pde_rms=np.nan, pinn_misfit=np.nan, pinn_start=np.nan)
                        else:
                            info, a0 = best
                            row.update(pinn_a=info["alpha"], pinn_D=info["D"], pinn_pde_rms=info["pde_rms"],
                                       pinn_misfit=info["data_misfit"], pinn_start=a0)
                        row["pinn_time"] = time.time() - t0
                    w.writerow(row)
                    f.flush()
                    print(f"sigma={sigma} m={m} trial={trial} done", flush=True)


def summarize(path, fail_rel=0.25):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    groups = {}
    for r in rows:
        groups.setdefault((float(r["sigma"]), int(r["m"])), []).append(r)

    def col(rs, k):
        return np.array([float(r[k]) if r.get(k, "") != "" else np.nan for r in rs])

    print(f"{'sigma':>7} {'m':>4} {'n':>4} | {'CRB_a':>8} {'NLS_a':>8} {'PINN_a':>8} | "
          f"{'CRB_D':>8} {'NLS_D':>8} {'PINN_D':>8} | {'fail_PINN':>9}")
    for (s, m), rs in sorted(groups.items()):
        out = []
        for p, k in (("a", THETA[0]), ("D", THETA[1])):
            crb = np.nanmean(col(rs, f"crb_{p}"))
            nls = np.sqrt(np.nanmean((col(rs, f"nls_{p}") - k) ** 2))
            pin = np.sqrt(np.nanmean((col(rs, f"pinn_{p}") - k) ** 2))
            out.append((crb, nls, pin))
        pa = col(rs, "pinn_a")
        fail = np.mean(np.isnan(pa) | (np.abs(pa - THETA[0]) / THETA[0] > fail_rel)) if not np.all(np.isnan(pa)) else np.nan
        print(f"{s:7.3g} {m:4d} {len(rs):4d} | "
              f"{out[0][0]:8.4f} {out[0][1]:8.4f} {out[0][2]:8.4f} | "
              f"{out[1][0]:8.4f} {out[1][1]:8.4f} {out[1][2]:8.4f} | {fail:9.2f}")
    print("\nBias (mesatarja e gabimit me shenje) [NLS, PINN] per alpha dhe D:")
    for (s, m), rs in sorted(groups.items()):
        b = [np.nanmean(col(rs, k) - v) for k, v in
             (("nls_a", THETA[0]), ("pinn_a", THETA[0]), ("nls_D", THETA[1]), ("pinn_D", THETA[1]))]
        print(f"{s:7.3g} {m:4d} | alpha: {b[0]:+.4f} {b[1]:+.4f} | D: {b[2]:+.4f} {b[3]:+.4f}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=20)
    ap.add_argument("--ms", type=int, nargs="+", default=[10, 20, 40])
    ap.add_argument("--sigmas", type=float, nargs="+", default=[0.01])
    ap.add_argument("--epochs", type=int, default=5000)
    ap.add_argument("--offset", type=int, default=0, help="indeksi i pare i trial-it (seed i ri per validim)")
    ap.add_argument("--res", default="l1", choices=["l1", "volterra"], help="humbja e fizikes")
    ap.add_argument("--alpha0", type=float, default=0.5, help="inicializimi i alpha te PINN (nje nisje)")
    ap.add_argument("--starts", type=float, nargs="+", default=None, help="multistart: disa alpha0; zgjidhet ajo me humbjen me te vogel")
    ap.add_argument("--model", default="spectral", choices=["spectral", "fpinn"], help="PINN spektral ose fPINN i plote (baseline)")
    ap.add_argument("--feature", default="t", choices=["t", "talpha"], help="hyrja kohore e fPINN")
    ap.add_argument("--M", type=int, default=200, help="hapat kohore te L1")
    ap.add_argument("--wfinal", type=float, default=1e5, help="pesha finale e penalizimit PDE")
    ap.add_argument("--skip", type=float, default=0.1, help="pjesa fillestare e [0,T] e perjashtuar nga mbetja")
    ap.add_argument("--D0", type=float, default=1.0, help="inicializimi i D (default 1.0)")
    ap.add_argument("--width", type=int, default=64, help="gjeresia e MLP (vetem spectral)")
    ap.add_argument("--depth", type=int, default=3, help="shtresat e fshehura (vetem spectral)")
    ap.add_argument("--lbfgs", type=int, default=300, help="iteracionet maksimale L-BFGS (vetem spectral)")
    ap.add_argument("--noise-scale", type=float, default=1.0, help="0 = te dhena pa zhurme (test i zhvendosjes deterministe)")
    ap.add_argument("--out", default="results_B.csv")
    ap.add_argument("--no-pinn", action="store_true")
    ap.add_argument("--summarize", default=None)
    a = ap.parse_args()
    if a.summarize:
        summarize(a.summarize)
    else:
        run(a)
        summarize(a.out)
